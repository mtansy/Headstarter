Headstarter Project 1 Website
Madi Tansy

Download the zip file to get all the assets, then click on "index.html" to view the site.